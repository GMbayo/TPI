package com.example.cynoclient

import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Spinner
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment

class FragNewClient : Fragment() {
    lateinit var textView: TextView
    var lastname = ""
    var firstname = ""
    var email = ""
    var phone = ""
    var address = ""
    var location = ""


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.new_client, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        textView = view.findViewById(R.id.newClient_text)
        textView.text  = "Client"

        val next = view.findViewById<ImageButton>(R.id.arrow_forward)
        next.setOnClickListener{
            nextPage()
        }
        val previous = view.findViewById<ImageButton>(R.id.arrow_back)
        previous.setOnClickListener{
            previousPage()
        }

        val addNewClient = view.findViewById<ImageButton>(R.id.newClient_addClient)
        addNewClient.setOnClickListener{
            addClient()
        }
    }

    private fun nextPage(){
        val ok = saveClient()

        if(ok) {
            val fragmentTransaction = fragmentManager!!.beginTransaction()
            fragmentTransaction.replace(R.id.myFragment, FragNewDog())
            fragmentTransaction.commit()
        }
    }

    private fun previousPage(){

        val fragmentTransaction = fragmentManager!!.beginTransaction()
        fragmentTransaction.replace(R.id.myFragment, FragNewPrestation())
        fragmentTransaction.commit()
    }

    private fun saveClient():Boolean{
        var isOK = true
        //Récupération des infos
        lastname = view!!.findViewById<EditText>(R.id.newClient_nom).text.toString()
        firstname = view!!.findViewById<EditText>(R.id.newClient_prenom).text.toString()
        email = view!!.findViewById<EditText>(R.id.newClient_email).text.toString()
        phone = view!!.findViewById<EditText>(R.id.newClient_tel).text.toString()
        phone = phone.replace(" ","")
        address = view!!.findViewById<EditText>(R.id.newClient_adresse).text.toString()
        location = view!!.findViewById<Spinner>(R.id.newClient_localite_spinner).toString()

        //Messages d'erreurs
        if(TextUtils.isEmpty(address)){
            view!!.findViewById<EditText>(R.id.newClient_adresse).error = "L'adresse est requise"
            view!!.findViewById<EditText>(R.id.newClient_adresse).requestFocus()
            isOK = false
        }
        if(TextUtils.isEmpty(phone)){
            view!!.findViewById<EditText>(R.id.newClient_tel).error = "Le numéro de téléphone est requis"
            view!!.findViewById<EditText>(R.id.newClient_tel).requestFocus()
            isOK = false
        }
        if(!phone.matches("^[+]?[0-9]{10,14}$".toRegex())){
            view!!.findViewById<EditText>(R.id.newClient_tel).error = "Le numéro de téléphone est incorrect"
            view!!.findViewById<EditText>(R.id.newClient_tel).requestFocus()
            isOK = false
        }
        if(TextUtils.isEmpty(email)){
            view!!.findViewById<EditText>(R.id.newClient_email).error = "L'e-mail est requis"
            view!!.findViewById<EditText>(R.id.newClient_email).requestFocus()
            isOK = false
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            view!!.findViewById<EditText>(R.id.newClient_email).error = "L'e-mail est incorrect"
            view!!.findViewById<EditText>(R.id.newClient_email).requestFocus()
            isOK = false
        }
        if(TextUtils.isEmpty(firstname)){
            view!!.findViewById<EditText>(R.id.newClient_prenom).error = "Le prénom est requis"
            view!!.findViewById<EditText>(R.id.newClient_prenom).requestFocus()
            isOK = false
        }
        if(TextUtils.isEmpty(lastname)){
            view!!.findViewById<EditText>(R.id.newClient_nom).error = "Le nom est requis"
            view!!.findViewById<EditText>(R.id.newClient_nom).requestFocus()
            isOK = false

        }
        //Ajouter l erreur pour le spinner de localité

        if(isOK){
            // code pour enregistrer les données du client

            return true
        }
        else{
            return false
        }
    }

    private fun addClient(){
        val ok = saveClient()

        if(ok){
            val fragmentTransaction = fragmentManager!!.beginTransaction()
            fragmentTransaction.replace(R.id.myFragment, FragNewClient())
            fragmentTransaction.commit()
        }
    }
}