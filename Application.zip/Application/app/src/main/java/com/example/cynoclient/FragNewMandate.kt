package com.example.cynoclient

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.fragment.app.Fragment

class FragNewMandate : Fragment() {
    lateinit var textView: TextView


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.new_mandate, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        textView = view.findViewById(R.id.newMandate_text)
        textView.text  = "Mandat"

        val next = view.findViewById<ImageButton>(R.id.arrow_forward)
        next.setOnClickListener{
            nextPage()
        }
        val previous = view.findViewById<ImageButton>(R.id.arrow_back)
        previous.setOnClickListener{
            previousPage()
        }
    }

    fun nextPage(){

        val fragmentTransaction = fragmentManager!!.beginTransaction()
        fragmentTransaction.replace(R.id.myFragment, FragNewMandate())
        fragmentTransaction.commit()
    }

    fun previousPage(){

        val fragmentTransaction = fragmentManager!!.beginTransaction()
        fragmentTransaction.replace(R.id.myFragment, FragNewPrestation())
        fragmentTransaction.commit()
    }
}