package com.example.cynoclient

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import com.google.android.material.textfield.TextInputEditText

class FragNewPrestation : Fragment() {
    lateinit var textView: TextView
    var date = ""
    lateinit var atHome: CheckBox
    var place = ""
    var duration = 0.0
    var type = ""
    var payed = false
    var description = ""


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.new_prestation, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<ImageButton>(R.id.arrow_back).isVisible = false

        textView = view.findViewById(R.id.newPrestation_text)
        textView.text  = "Prestation"

        val next = view.findViewById<ImageButton>(R.id.arrow_forward)
        next.setOnClickListener{
            nextPage()
        }
        val previous = view.findViewById<ImageButton>(R.id.arrow_back)
        previous.setOnClickListener{
            previousPage()
        }
        atHome = view.findViewById<CheckBox>(R.id.newPrestation_chk_place)
        atHome.setOnClickListener {
            view.findViewById<Spinner>(R.id.newPrestation_place_spinner).isClickable = !atHome.isChecked
        }
    }

    private fun nextPage(){

        val fragmentTransaction = fragmentManager!!.beginTransaction()
        fragmentTransaction.replace(R.id.myFragment, FragNewClient())
        fragmentTransaction.commit()
    }

    private fun previousPage(){

        val fragmentTransaction = fragmentManager!!.beginTransaction()
        fragmentTransaction.replace(R.id.myFragment, FragNewPrestation())
        fragmentTransaction.commit()
    }

    private fun savePrestation():Boolean{
        var isOK = true

        //Récupération des infos
        date = view!!.findViewById<EditText>(R.id.newPrestation_date).text.toString()
        if(atHome.isChecked){
            place = "" //The client's adress
        }
        else{
            place = view!!.findViewById<Spinner>(R.id.newPrestation_place_spinner).toString()
        }
        duration = if(view!!.findViewById<EditText>(R.id.newPrestation_duration).text.toString() == ""){
            1.0
        } else{
            view!!.findViewById<EditText>(R.id.newPrestation_duration).text.toString().toDouble()
        }
        payed = view!!.findViewById<CheckBox>(R.id.newPrestation_chk_payed).isChecked
        description = view!!.findViewById<TextInputEditText>(R.id.newPrestation_description).text.toString()

        //Messages d'erreurs
        if(TextUtils.isEmpty(description)){
            view!!.findViewById<EditText>(R.id.newPrestation_description).error = "Une description est requise"
            view!!.findViewById<EditText>(R.id.newPrestation_description).requestFocus()
            isOK = false
        }
        if(TextUtils.isEmpty(date)){
            view!!.findViewById<EditText>(R.id.newPrestation_date).error = "Une date est requise"
            view!!.findViewById<EditText>(R.id.newPrestation_date).requestFocus()
            isOK = false
        }
        return false
    }
}