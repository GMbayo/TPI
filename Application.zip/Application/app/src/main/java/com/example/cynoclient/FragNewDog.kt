package com.example.cynoclient

import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment

class FragNewDog : Fragment() {
    lateinit var textView: TextView
    var name = ""
    var sexe = ""
    var breed = ""
    var crossed = ""
    var birth = ""
    var sterilized = false
    var sick = false
    var belong = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.new_dog, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.findViewById<TextView>(R.id.newDog_lbl_belong).isVisible = false
        view.findViewById<Spinner>(R.id.newDog_belong_spinner).isVisible = false

        textView = view.findViewById(R.id.newDog_text)
        textView.text  = "Chien"

        val next = view.findViewById<ImageButton>(R.id.arrow_forward)
        next.setOnClickListener{
            nextPage()
        }
        val previous = view.findViewById<ImageButton>(R.id.arrow_back)
        previous.setOnClickListener{
            previousPage()
        }
        val addNewDog = view.findViewById<ImageButton>(R.id.newDog_addDog)
        addNewDog.setOnClickListener{
            addDog()
        }
    }

    private fun nextPage(){
        val ok = saveDog()

        if(ok) {
            val fragmentTransaction = fragmentManager!!.beginTransaction()
            fragmentTransaction.replace(R.id.myFragment, FragNewMandate())
            fragmentTransaction.commit()
        }
    }

    private fun previousPage(){

        val fragmentTransaction = fragmentManager!!.beginTransaction()
        fragmentTransaction.replace(R.id.myFragment, FragNewClient())
        fragmentTransaction.commit()
    }

    private fun saveDog():Boolean{
        var isOK = true
        //récupération des infos
        name = view!!.findViewById<EditText>(R.id.newDog_nom).text.toString()
        if(view!!.findViewById<RadioGroup>(R.id.newDog_sexe_rb_group).checkedRadioButtonId == R.id.newDog_rb_male){
            sexe = "mâle"
        }
        else if(view!!.findViewById<RadioGroup>(R.id.newDog_sexe_rb_group).checkedRadioButtonId == R.id.newDog_rb_female){
            sexe = "femelle"
        }
        breed = view!!.findViewById<Spinner>(R.id.newDog_breed_spinner).toString()
        crossed = view!!.findViewById<Spinner>(R.id.newDog_crossed_spinner).toString()
        birth = view!!.findViewById<EditText>(R.id.newDog_naissance).text.toString()
        sterilized = view!!.findViewById<CheckBox>(R.id.newDog_chk_sterilized).isChecked
        sick = view!!.findViewById<CheckBox>(R.id.newDog_chk_sick).isChecked
        belong = view!!.findViewById<Spinner>(R.id.newDog_belong_spinner).toString()

        //Messages d'erreurs
            //ajouter le contrôl pour belong
        if(TextUtils.isEmpty(birth)){
            view!!.findViewById<EditText>(R.id.newDog_naissance).error = "Une date de naissance est requise"
            view!!.findViewById<EditText>(R.id.newDog_naissance).requestFocus()
            isOK = false
        }
            //ajouter le contrôl de breed et de crossed
        if(TextUtils.isEmpty(sexe)){
            view!!.findViewById<RadioButton>(R.id.newDog_rb_female).error = "Le sexe est requis"
            view!!.findViewById<RadioButton>(R.id.newDog_rb_female).requestFocus()
            isOK = false
        }
        if(TextUtils.isEmpty(name)){
            view!!.findViewById<EditText>(R.id.newDog_nom).error = "Le nom est requis"
            view!!.findViewById<EditText>(R.id.newDog_nom).requestFocus()
            isOK = false
        }

        if(isOK){
            //Code pour sauvegarder le chien
            return true
        }
        else{
            return false
        }
    }

    private fun addDog(){
        val ok = saveDog()

        if(ok) {
            val fragmentTransaction = fragmentManager!!.beginTransaction()
            fragmentTransaction.replace(R.id.myFragment, FragNewDog())
            fragmentTransaction.commit()
        }
    }
}